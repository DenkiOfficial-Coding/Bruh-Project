# 🥑 BoLacNe 
Mã nguồn của bot **Bơ Lắc Nè#7041**
## 🎏 Các lệnh
<a  href="https://discord.gg/WhzaU6CGKV"><img src="https://cdn.discordapp.com/attachments/866532087863050271/902946373966635018/unknown.png"></a>
## 💫 Tính năng
- Hệ thống Economy
- Discord Together
- Shop nhẫn
- Marry
- Ảnh ngẫu nhiên
- Các lệnh cho cờ bạc như blackjack, baucua, taixiu,...
- Giveaway
## ⁉ Lưu ý
- Các bạn có thể lấy source code về để tạo bot mới nhưng vui lòng thêm credit của mình vào nhé
- Khi dùng source này sẽ bị lỗi vài emoji do bot không ở server có chứa emoji
- Link server có emoji bài cho blackjack https://discord.gg/zT7HehheqA, ai muốn add liên hệ CatCat#7311!
